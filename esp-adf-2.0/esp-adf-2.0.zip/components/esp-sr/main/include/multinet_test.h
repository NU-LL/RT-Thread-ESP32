#pragma once

void multinet_test();
