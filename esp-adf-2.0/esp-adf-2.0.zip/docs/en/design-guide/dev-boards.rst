Development Boards
******************

Hardware details of audio development boards designed by Espressif around ESP32.

.. toctree::
    :maxdepth: 1

    ESP32-LyraT-Mini V1.2 <board-esp32-lyrat-mini-v1.2>
    ESP32-LyraT V4.3 <board-esp32-lyrat-v4.3>
    ESP32-LyraT V4.2 <../get-started/get-started-esp32-lyrat-v4.2>
    ESP32-LyraT V4 <../get-started/get-started-esp32-lyrat-v4>
