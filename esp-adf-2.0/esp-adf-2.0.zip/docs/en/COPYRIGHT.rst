Copyrights and Licenses
***********************

Software Copyrights
===================

All original source code in this repository is Copyright (C) 2015-2018
Espressif Systems. This source code is licensed under the ESPRESSIF MIT
License as described in the file LICENSE.

Additional third party copyrighted code is included under the following licenses:

* :component:`esp-stagefright <esp-adf-libs/esp_codec/esp-stagefright>` is Copyright (c) 2005-2008, The Android Open Source Project, and is licensed under the Apache License Version 2.0.

Please refer to the `COPYRIGHT <http://esp-idf.readthedocs.io/en/latest/COPYRIGHT.html>`_ in ESP-IDF Programming Guide

Where source code headers specify Copyright & License information, this information takes precedence over the summaries made here.
