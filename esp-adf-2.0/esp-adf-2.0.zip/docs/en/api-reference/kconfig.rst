Configuration Options
*********************

Compile-time configuration options specific to ESP-ADF.

.. include:: /_build/inc/kconfig.inc
