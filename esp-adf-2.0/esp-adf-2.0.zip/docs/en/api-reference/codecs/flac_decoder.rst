FLAC Decoder
============

Decode an audio data stream provided in FLAC format.


API Reference
-------------

.. include:: /_build/inc/flac_decoder.inc

