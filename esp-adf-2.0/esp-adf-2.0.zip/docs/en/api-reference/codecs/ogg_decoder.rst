OGG Decoder
===========

Decode an audio data stream provided in OGG format.


API Reference
-------------

.. include:: /_build/inc/ogg_decoder.inc

