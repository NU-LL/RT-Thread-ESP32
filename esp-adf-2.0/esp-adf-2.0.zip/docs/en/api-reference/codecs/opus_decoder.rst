OPUS Decoder
============

Decode an audio data stream provided in OPUS format.


API Reference
-------------

.. include:: /_build/inc/opus_decoder.inc

