MP3 Decoder
===========

Decode an audio data stream provided in MP3 format.


Application Examples
--------------------

Implementation of this API is demonstrated in the following examples:

* :example:`get-started/play_mp3`
* :example:`player/pipeline_sdcard_mp3`


API Reference
-------------

.. include:: /_build/inc/mp3_decoder.inc

