Codecs
******

.. toctree::
    :maxdepth: 1

    AAC Decoder <aac_decoder>
    AMR Decoder and Encoder <amr_codecs>
    FLAC Decoder <flac_decoder>
    MP3 Decoder <mp3_decoder>
    OGG Decoder <ogg_decoder>
    OPUS Decoder <opus_decoder>
    WAV Decoder and Encoder <wav_codecs>
