AAC Decoder
===========

Decode an audio data stream provided in AAC format.


API Reference
-------------

.. include:: /_build/inc/aac_decoder.inc

