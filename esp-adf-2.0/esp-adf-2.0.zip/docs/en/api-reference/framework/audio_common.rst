Audio Common
============

Enumerations that define type of :doc:`Audio Elements <audio_element>`, type and format of :doc:`Codecs <../codecs/index>` and type of :doc:`Streams <../streams/index>`.


API Reference
-------------

.. include:: /_build/inc/audio_common.inc
