ESP Audio
=========

This component provides several simple high level APIs. It is intended for quick implementation of audio applications based on typical interconnections of standardized audio elements.


API Reference
-------------

.. include:: /_build/inc/audio_def.inc

.. include:: /_build/inc/esp_audio.inc
