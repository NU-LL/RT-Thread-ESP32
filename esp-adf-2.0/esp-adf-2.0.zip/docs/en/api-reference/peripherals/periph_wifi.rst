Wi-Fi Peripheral
================

The Wi-Fi Peripheral is used to configure Wi-Fi connections, provide APIs to control Wi-Fi connection configuration, as well as monitor the status of Wi-Fi networks.


Application Example
-------------------

Implementation of this API is demonstrated in :example:`player/pipeline_http_mp3` example.


API Reference
-------------

.. include:: /_build/inc/periph_wifi.inc

