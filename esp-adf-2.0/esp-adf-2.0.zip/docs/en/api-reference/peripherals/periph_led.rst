LED Peripheral
==============

Blink or fade a LED connected to a GPIO with configurable On and Off times.


Application Examples
--------------------

Implementation of this API is demonstrated in couple of examples:

* :example:`/cloud_services/google_translate_device`
* :example:`/dueros`


API Reference
-------------

.. include:: /_build/inc/periph_led.inc
