Touch Peripheral
================

Initialize ESP32 touchpad peripheral and retrieve information from the touch sensors. 


Application Example
-------------------

Implementation of this API is demonstrated in :example:`get-started/play_mp3_control` example.


API Reference
-------------

.. include:: /_build/inc/periph_touch.inc

